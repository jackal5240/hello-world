window.apiTesterConfig = {
  installId : "98hD-SDXs-8sq1-NTH7-sdGS-566h",
  campusId : 30000,
  ccapi_server_url : "http://www.wdpmooc.com",
  user_account : "studentqa",
  user_password : "111111"
};